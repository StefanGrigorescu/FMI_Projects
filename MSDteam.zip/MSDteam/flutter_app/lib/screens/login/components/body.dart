import 'package:flutter/material.dart';
import 'package:flutter_app/screens/login/components/login_form.dart';

class Body extends StatelessWidget {
  const Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const LoginForm();
  }
}
