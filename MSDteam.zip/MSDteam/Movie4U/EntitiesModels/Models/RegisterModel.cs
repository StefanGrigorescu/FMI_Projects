﻿
namespace Movie4U.EntitiesModels.Models
{
    public class RegisterModel
    {
        public string userName { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string role { get; set; }
    }
}
