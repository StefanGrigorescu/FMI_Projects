﻿
namespace Movie4U.EntitiesModels.Models
{
    public class LoginModel
    {
        public string emailOrName { get; set; }
        public string password { get; set; }
    }
}
