﻿using Microsoft.AspNetCore.Identity;

namespace Movie4U.EntitiesModels.Entities
{
    public class UserRole : IdentityUserRole<string>
    {
    }
}
