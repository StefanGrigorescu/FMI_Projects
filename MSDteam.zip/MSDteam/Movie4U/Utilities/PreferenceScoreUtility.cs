﻿
namespace Movie4U.Utilities
{
    public static class PreferenceScoreUtility
    {
        //public static double GetScore(WatcherTitle watcherTitle)
        //{
        //    List<TitleGenres> genres = watcherTitle.title.titleGenres;
        //}
    }
}
