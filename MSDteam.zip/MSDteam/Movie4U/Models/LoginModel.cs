﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Movie4U.Models
{
    public class LoginModel
    {
        public string emailOrName { get; set; }
        public string password { get; set; }
    }
}
