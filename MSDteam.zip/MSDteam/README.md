# netflix-recommendations 

### App used for finding Netflix titles available in your country

The goal is to create a music player like interface where you can like/dislike movies to get more/less movies like them or add them to your watchlist.



