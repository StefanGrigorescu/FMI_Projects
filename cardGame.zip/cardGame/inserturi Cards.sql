﻿--delete from cards;

-- card_name, card_type, civilisation, race, energy_cost, power, evolution creature, set_name
insert into cards
values('Barnville Runaway', 'Unit', 'Auf', 'Aufytale', 3, 1, 0, 'cG1 - First Settlers'); -- resource gatherer +1

insert into cards
values('Tireless Hunter', 'Unit', 'Auf', 'Crimeauf', 2, 5, 1, 'cG1 - First Settlers'); -- mad raider +1

insert into cards
values('Shady Newcomer', 'Unit', 'Auf', 'Crimeauf', 1, 1, 0, 'cG1 - First Settlers'); 

insert into cards
values('Skull Piercer', 'Unit', 'Auf', 'Rockauf', 3, 3, 0, 'cG1 - First Settlers');

insert into cards 
values('Garrison Guard', 'Unit', 'Auf', 'Historicalauf', 5, 4, 0, 'cG1 - First Settlers'); -- counter-offensive

insert into cards
values('Ruthless Gatekeeper', 'Unit', 'Auf', 'Historicalauf', 2, 2, 0, 'cG1 - First Settlers'); -- defender 

insert into cards
values('Woods Folk', 'Unit', 'Auf', 'Aufcasual', 1, 2, 0, 'cG1 - First Settlers'); 

insert into cards
values('The Pathfinder', 'Unit', 'Auf', 'Workerauf', 3, 1, 0, 'cG1 - First Settlers'); -- resource gatherer +1

insert into cards
values('Field Watcher', 'Unit', 'Auf', 'Workerauf', 1, 2, 0, 'cG1 - First Settlers'); -- defender

insert into cards
values('Frontline Breaker', 'Unit', 'Auf', 'Warfareauf', 4, 2, 0, 'cG1 - First Settlers'); -- reaper warrior 

insert into cards
values('Shadow Sower', 'Unit', 'Auf', 'Aufcasual', 3, 1, 0, 'cG1 - First Settlers'); -- scout

insert into cards
values('Young Partisan', 'Unit', 'Auf', 'Aufcasual', 3, 4, 0, 'cG1 - First Settlers'); -- defender 

insert into cards
values('Swift Silencer', 'Rune', 'Auf', '-', 2, 0, 0, 'cG1 - First Settlers'); -- (rune): defender bane, ancient curse

insert into cards
values('Storm Traveler', 'Unit', 'Rider', 'Skyrider', 3, 2, 0, 'cG1 - First Settlers'); -- cavalry assault 

insert into cards
values('Wild Horn', 'Unit', 'Rider', 'Northrider', 3, 3, 0, 'cG1 - First Settlers'); -- mad raider +2

insert into cards
values('Lightning Charger', 'Unit', 'Rider', 'Northrider', 3, 2, 1, 'cG1 - First Settlers'); -- resource gathererer +2, mad raider +2

insert into cards
values('Cornered Beast', 'Unit', 'Rider', 'Northrider', 2, 3, 0, 'cG1 - First Settlers'); 

insert into cards
values('Sole Stallion', 'Unit', 'Rider', 'Unrideable', 3, 2, 0, 'cG1 - First Settlers'); -- mad raider +2

insert into cards
values('Skyquake Crusher', 'Unit', 'Rider', 'Skyrider', 3, 1, 0, 'cG1 - First Settlers'); -- cavalry assault, mad raider +3

insert into cards
values('Snow Chariot of Northriders', 'Unit', 'Rider', 'Northrider', 3, 4, 1, 'cG1 - First Settlers'); -- mad raider +3

insert into cards
values('Skyfall', 'Rune', 'Rider', '-', 2, 0, 0, 'cG1 - First Settlers'); -- (rune): safe hit <=2

insert into cards
values('Bones Canyon', 'Rune', 'Auf', '-', 6, 0, 0, 'cG1 - First Settlers'); -- (rune): death and taxes, ancient curse

select * from cards;

