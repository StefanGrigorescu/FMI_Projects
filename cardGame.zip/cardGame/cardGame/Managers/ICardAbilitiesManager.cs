﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public interface ICardAbilitiesManager
    {
        List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilities();
        List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesOfCard(string cardName);
        Task Create(CardAbilityModel source);
        Task CreateSet(List<CardAbilityModel> sourceList);
        Task Update(CardAbilityModel source);
        Task Delete(string abilityName, string cardName);
    }
}
