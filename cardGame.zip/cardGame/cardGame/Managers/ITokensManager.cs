﻿using cardGame.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public interface ITokensManager
    {
        Task<string> GenerateToken(User user);
    }
}
