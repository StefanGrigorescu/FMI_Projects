﻿using cardGame.Classes;
using cardGame.Models;
using cardGame.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public class CardAbilitiesManager: ICardAbilitiesManager
    {
        private readonly ICardAbilitiesRepository repo;

        public CardAbilitiesManager(ICardAbilitiesRepository repo)
        {
            this.repo = repo;
        }

        public List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilities()
        {
            return repo.GetCardAbilitiesJoinedAbilities();
        }

        public List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesOfCard(string cardName)
        {
            return repo.GetCardAbilitiesJoinedAbilitiesOfCard(cardName);
        }

        public async Task Create(CardAbilityModel source)
        {
            var newCardAbility = new CardAbility { };
            newCardAbility.copy(source);

            await repo.Create(newCardAbility);
        }

        public async Task CreateSet(List<CardAbilityModel> sourceList)
        {
            foreach (CardAbilityModel source in sourceList)
                await Create(source);
         }

        public async Task Update(CardAbilityModel source)
        {
            CardAbility editCardAbility = 
                repo.
                GetOneCardAbilityByCompKey(source.ability_name, source.card_name);

            // check for null
            if (editCardAbility != null)
            {
                // update available field, namely quantity
                editCardAbility.quantity = source.quantity;

                await repo.Update(editCardAbility);
            }
        }

        public async Task Delete(string abilityName, string cardName)
        {
            CardAbility delCardAbility =
                repo.
                GetOneCardAbilityByCompKey(abilityName, cardName);

            // delete
            await repo.Delete(delCardAbility);
        }
    }
}
