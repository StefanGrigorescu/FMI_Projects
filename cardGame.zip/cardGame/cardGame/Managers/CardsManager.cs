﻿using cardGame.Classes;
using cardGame.Models;
using cardGame.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public class CardsManager: ICardsManager
    {
        private readonly ICardsRepository repo;
        private readonly ICardAbilitiesRepository cardAbilitiesRepo;

        public CardsManager(ICardsRepository repo, ICardAbilitiesRepository cardAbilitiesRepo)
        {
            this.repo = repo;
            this.cardAbilitiesRepo = cardAbilitiesRepo;
        }


        public CardReturnedModel cardReturnedWithAbilitiesLoaded(CardReturnedModel cardReturned)
        {
            // get card abilities (in returned format) of card by card_name 
            List<CardAbilityReturnedModel> cardAbilities =
                cardAbilitiesRepo
                .GetCardAbilitiesJoinedAbilitiesOfCard(cardReturned.card_name);

            // for each card ability in returned format
            foreach (CardAbilityReturnedModel cardAbility in cardAbilities)
            {
                // make card ability in 'card ability of card' format
                //      (same as previous format, but without the unnecessary duplicated card_name)
                CardAbilityOfCardModel cardAbilityFiltered = new CardAbilityOfCardModel();
                cardAbilityFiltered.copy(cardAbility);

                cardReturned.abilitiesList.Add(cardAbilityFiltered);
            }

            return cardReturned;
        }

        public List<CardReturnedModel> cardReturnedWithAbilitiesLoadedList(List<CardReturnedModel> cardsReturned)
        {
            for (int i = 0; i < cardsReturned.Count; i++)
                cardsReturned[i] =
                    cardReturnedWithAbilitiesLoaded(cardsReturned[i]);

            return cardsReturned;
        }


        public List<CardReturnedModel> GetAllCards()
        {
            // get card list in returned format
            List<CardReturnedModel> cardsReturned =
               repo.
               GetAllCards(); 

            // load their abilities 
            cardsReturned =
                cardReturnedWithAbilitiesLoadedList(cardsReturned);

            return cardsReturned;
        }

        public List<CardReturnedModel> GetCardsByName(string name)
        {
            // get card list by name, in returned format
            List<CardReturnedModel> cardsReturned = 
                repo
                .GetCardsByName(name);

            // load their abilities 
            cardsReturned =
                cardReturnedWithAbilitiesLoadedList(cardsReturned);

            return cardsReturned;
        }

        public Card GetOneDbCardByName(string name)
        {
            return repo.GetOneDbCardByName(name);
        }

        public CardReturnedModel GetOneCardReturnedModelByName(string name)
        {
            // get card in returned format
            CardReturnedModel cardReturned =
                repo
                .GetOneCardByName(name);

            // load it's abilities
            if (cardReturned != null)
                cardReturned = 
                    cardReturnedWithAbilitiesLoaded(cardReturned);

            return cardReturned;
        }

        public List<CardReturnedModel> PostFiltersToGetCards(CardFiltersModel filters)
        {
            // get card in returned format
            List<CardReturnedModel> cardsReturned =
                repo
                .PostFiltersToGetCards(filters);

            // load their abilities
            cardsReturned =
                cardReturnedWithAbilitiesLoadedList(cardsReturned);

            return cardsReturned;
        }
        
        public async Task Create(CardModel source)
        {
            // create new Card and load source's data
            var newCard = 
                new Card { card_name = source.card_name};
            newCard.copy(source);

            await repo.Create(newCard);
        }

        public async Task CreateSet(List<CardModel> sourceList)
        {
            foreach (CardModel source in sourceList)
                await Create(source);
        }

        public async Task Update(CardModel source)
        {
            // get Card or null
            var editCard = repo.GetOneDbCardByName(source.card_name);
            
            if (editCard != null)
            {
                // update newCard's data, except it's card_name (PK)
                editCard.copy(source);

                await repo.Update(editCard);
            }
        }

        public async Task Delete(string cardName)
        {
            var delCard = GetOneDbCardByName(cardName);

            if(delCard != null)
            {
                // get card abilities bound by delCard
                List<CardAbility> caList = 
                    cardAbilitiesRepo
                    .GetCardAbilitiesOfCard(cardName);

                // delete delCard's abilities
                foreach(CardAbility ca in caList)
                    await cardAbilitiesRepo.Delete(ca);

                // delete delCard 
                await repo.Delete(delCard);
            }
        }
    }
}
