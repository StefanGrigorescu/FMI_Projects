﻿using cardGame.Classes;
using cardGame.Models;
using cardGame.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public class CardsManager: ICardsManager
    {
        private readonly ICardsRepository repo;
        private readonly ICardAbilitiesRepository cardAbilitiesRepo;

        public CardsManager(ICardsRepository repo, ICardAbilitiesRepository cardAbilitiesRepo)
        {
            this.repo = repo;
            this.cardAbilitiesRepo = cardAbilitiesRepo;
        }

        public List<CardReturnedModel> GetAllCards()
        {
            return repo.GetAllCards();
        }

        public List<CardReturnedModel> GetCardsByName(string name)
        {
            return repo.GetCardsByName(name);
        }

        public Card GetOneDbCardByName(string name)
        {
            return repo.GetOneDbCardByName(name);
        }

        public CardReturnedModel GetOneCardReturnedModelByName(string name)
        {
            return repo.GetOneCardByName(name);
        }

        public List<CardReturnedModel> PostFiltersToGetCards(CardFiltersModel filters)
        {
            return repo.PostFiltersToGetCards(filters);
        }
        
        public async Task Create(CardModel source)
        {
            // create new Card and load source's data
            var newCard = 
                new Card { card_name = source.card_name};
            newCard.copy(source);

            await repo.Create(newCard);
        }

        public async Task CreateSet(List<CardModel> sourceList)
        {
            foreach (CardModel source in sourceList)
                await Create(source);
        }

        public async Task Update(CardModel source)
        {
            // get Card or null
            var editCard = repo.GetOneDbCardByName(source.card_name);
            
            if (editCard != null)
            {
                // update newCard's data, except it's card_name (PK)
                editCard.copy(source);

                await repo.Update(editCard);
            }
        }

        public async Task Delete(string cardName)
        {
            var delCard = GetOneDbCardByName(cardName);

            if(delCard != null)
            {
                // get card abilities bound by delCard
                List<CardAbility> caList = 
                    cardAbilitiesRepo
                    .GetCardAbilitiesOfCard(cardName);

                // delete delCard's abilities
                foreach(CardAbility ca in caList)
                    await cardAbilitiesRepo.Delete(ca);

                // delete delCard 
                await repo.Delete(delCard);
            }
        }
    }
}
