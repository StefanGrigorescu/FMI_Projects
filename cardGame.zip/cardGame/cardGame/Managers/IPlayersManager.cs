﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public interface IPlayersManager
    {
        List<PlayerModel> GetAll();
        PlayerModel GetPlayerModel(string name);
        Task Create(PlayerCreationModel playerCreationModel);
        Task UpdatePassword(string playerName, string newPassword);
        Task UpdateWinRate(string playerName, double winRate);
        Task Delete(string name);
    }
}
