﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public interface ICardsManager
    {
        List<CardReturnedModel> GetAllCards();
        List<CardReturnedModel> GetCardsByName(string name);
        Card GetOneDbCardByName(string name);
        CardReturnedModel GetOneCardReturnedModelByName(string name);
        List<CardReturnedModel> PostFiltersToGetCards(CardFiltersModel filters);
        Task Create(CardModel source);
        Task CreateSet(List<CardModel> sourceList);
        Task Update(CardModel source);
        Task Delete(string cardName);
    }
}
