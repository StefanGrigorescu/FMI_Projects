﻿using cardGame.Classes;
using cardGame.Models;
using cardGame.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Managers
{
    public class PlayersManager : IPlayersManager
    {
        private readonly IPlayersRepository repo;

        public PlayersManager(IPlayersRepository repo)
        {
            this.repo = repo;
        }


        public List<PlayerModel> GetAll()
        {
            return repo.GetAll();
        }

        public PlayerModel GetPlayerModel(string name)
        {
            return repo.GetPlayerModel(name);
        }

        public async Task Create(PlayerCreationModel playerCreationModel)
        {
            var rng = new Random();

            Player newPlayer = new Player
            {
                player_name = playerCreationModel.player_name,
                password = playerCreationModel.password,
                register_date = 
                    DateTime
                    .Now
                    .AddDays(-1 * rng.Next(14))
                    .AddHours(-1 * rng.Next(23))
                    .AddMinutes(-1 * rng.Next(59)),
                win_rate = 1    
        };

            await repo.Create(newPlayer);
        }

        public async Task UpdatePassword(string playerName, string newPassword)
        {
            Player player = repo.GetPlayer(playerName);

            if (player != null)
            {
                player.password = newPassword;

                await repo.Update(player);
            }
        }

        public async Task UpdateWinRate(string playerName, double winRate)
        {
            Player player = repo.GetPlayer(playerName);

            if (player != null)
            {
                player.win_rate = winRate;

                await repo.Update(player);
            }
        }

        public async Task Delete(string name)
        {
            Player player = repo.GetPlayer(name);

            if (player != null)
                await repo.Delete(player);
        }
    }
}
