﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public interface ICardsRepository
    {
        List<CardReturnedModel> GetAllCards();
        Card GetOneDbCardByName(string name);
        CardReturnedModel GetOneCardByName(string name);
        List<CardReturnedModel> GetCardsByName(string name);
        List<CardReturnedModel> PostFiltersToGetCards(CardFiltersModel filters);
        Task Create(Card card);
        Task Update(Card card);
        Task Delete(Card card);
    }
}
