﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public class PlayersRepository: IPlayersRepository
    {
        // the context
        private readonly cardGameContext db;

        // the constructor
        public PlayersRepository(cardGameContext theContext)
        {
            this.db = theContext;
        }


        public List<PlayerModel> GetAll()
        {
            List<Player> players =
                db
                .Players
                .ToList();

            List<PlayerModel> playerModels = new List<PlayerModel> { };
            foreach(Player player in players)
            {
                var playerModel = 
                    new PlayerModel
                    {   player_name = player.player_name, 
                        register_date = player.register_date, 
                        win_rate = player.win_rate 
                    };
                playerModels.Add(playerModel);
            }

            return playerModels;
        }

        public Player GetPlayer(string name)
        {
            var player =
                db
                .Players
                .FirstOrDefault(p => p.player_name == name);

            return player;
        }

        public PlayerModel GetPlayerModel(string name)
        {
            var player = GetPlayer(name);
            var playerModel = new PlayerModel { };
            playerModel.copy(player);

            return playerModel;
        }

        public async Task Create(Player player)
        {
            await db.Players.AddAsync(player);

            await db.SaveChangesAsync();
        }

        public async Task Update(Player player)
        {
            db.Players.Update(player);

            await db.SaveChangesAsync();
        }

        public async Task Delete(Player player)
        {
            db.Players.Remove(player);

            await db.SaveChangesAsync();
        }
    }
}
