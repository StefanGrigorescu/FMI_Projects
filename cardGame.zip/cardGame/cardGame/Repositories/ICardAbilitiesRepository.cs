﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public interface ICardAbilitiesRepository
    {
        IQueryable<CardAbility> GetCardAbilitiesQuery();
        IQueryable<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesQuery();
        List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilities();
        List<CardAbility> GetCardAbilitiesOfCard(string cardName);
        List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesOfCard(string cardName);
        CardAbility GetOneCardAbilityByCompKey(string abilityName, string cardName);
        Task Create(CardAbility cardAbility);
        Task Update(CardAbility cardAbility);
        Task Delete(CardAbility cardAbility);
    }
}
