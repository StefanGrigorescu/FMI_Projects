﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public class CardsRepository : ICardsRepository
    {
        // the context
        private readonly cardGameContext db;

        // the constructor
        public CardsRepository(cardGameContext theContext)
        {
            this.db = theContext;
        }


        public CardReturnedModel FilterCardColumns(Card card)
        {
            var cardFiltered = 
                new CardReturnedModel();

            cardFiltered
                .copy(card);

            return cardFiltered;
        }

        public List<CardReturnedModel> FilterCardListColumns(List<Card> cardList)
        {
            var returnedCards = 
                new List<CardReturnedModel>();

            foreach (Card card in cardList)
                returnedCards
                    .Add(FilterCardColumns(card));

            return returnedCards;
        }


        public List<CardReturnedModel> GetAllCards()
        {
            // get cards from database
            List<Card> cards = 
                db
                .Cards
                .OrderBy(c => c.race)
                .ToList();

            // make cards in returned format
            List<CardReturnedModel> cardsReturned =
                FilterCardListColumns(cards);

            // return the cards in returned format
            return cardsReturned;
        }

        public Card GetOneDbCardByName(string name)
        {
            // get from db
            var oneCard = 
                db
                .Cards
                .FirstOrDefault(card => card.card_name == name);

            return oneCard;
        }

        public CardReturnedModel GetOneCardByName(string name)
        {
            // get from db
            var oneCard =
                GetOneDbCardByName(name);

            // filter
            if (oneCard != null)
            {
                CardReturnedModel cardReturned =
                    FilterCardColumns(oneCard);

                return cardReturned;
            }
            
            return null; 
        }

        public List<CardReturnedModel> GetCardsByName(string name)
        {
            // get from db
            List<Card> cards = 
                db
                .Cards
                .Where(card => card.card_name.Contains(name))
                .ToList();

            // filter
            List<CardReturnedModel> cardsReturned =
                FilterCardListColumns(cards);

            return cardsReturned;
        }

        public List<CardReturnedModel> PostFiltersToGetCards(CardFiltersModel filters)
        {
            // get from db
            List<Card> cards = 
                db.Cards
                .Where(c => filters.types.Contains(c.card_type) && 
                filters.civilisations.Contains(c.civilisation) && 
                filters.races.Contains(c.race) &&
                filters.energyMin <= c.energy_cost &&
                filters.energyMax >= c.energy_cost &&
                filters.powerMin <= c.power && 
                filters.PowerMax >= c.power &&
                filters.evolution == c.evolution_creature &&
                filters.sets.Contains(c.set_name)
                )
                .ToList();

            // filter
            List<CardReturnedModel> cardsReturned =
                FilterCardListColumns(cards);

            return cardsReturned;
        }

        public async Task Create(Card card)
        {
            await db.Cards.AddAsync(card);

            await db.SaveChangesAsync();
        }

        public async Task Update(Card card)
        {
            db.Cards.Update(card);

            await db.SaveChangesAsync();
        }

        public async Task Delete(Card card)
        {
            db.Cards.Remove(card);

            await db.SaveChangesAsync();
        }
    }
}
