﻿using cardGame.Classes;
using cardGame.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public class CardAbilitiesRepository: ICardAbilitiesRepository
    {
        // the context
        private readonly cardGameContext db;

        // the constructor
        public CardAbilitiesRepository(cardGameContext theContext)
        {
            this.db = theContext;
        }

        // all CardAbilities in database format; IQueryable
        public IQueryable<CardAbility> GetCardAbilitiesQuery()
        {
            IQueryable<CardAbility> cardAbilitiesQuery = 
                db.Card_Abilities;
            return cardAbilitiesQuery;
        }

        // all CardAbilities in return format; IQueryable
        public IQueryable<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesQuery()
        {
            IQueryable<CardAbilityReturnedModel> cardAbilitiesJoinedAbilitiesQuery =
                GetCardAbilitiesQuery()
                .Include(ca => ca.ability)
                .Select(ca => new CardAbilityReturnedModel
                {   ability_name = ca.ability_name, 
                    card_name = ca.card_name, 
                    quantity = ca.quantity, 
                    effect_details = ca.ability.effect_details });

            return cardAbilitiesJoinedAbilitiesQuery;
        }

        // all CardAbilities in return format; List
        public List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilities()
        {
            List<CardAbilityReturnedModel> cardAbilitiesJoined = 
                GetCardAbilitiesJoinedAbilitiesQuery()
                .ToList();
            return cardAbilitiesJoined;
        }

        // CardAbilities of one card, in database format; List
        public List<CardAbility> GetCardAbilitiesOfCard(string cardName)
        {
            List<CardAbility> abilitiesOfCard = 
                GetCardAbilitiesQuery()
                .Where(ca => ca.card_name == cardName)
                .ToList();

            return abilitiesOfCard;
        }

        // CardAbilities of one card, in return format; List
        public List<CardAbilityReturnedModel> GetCardAbilitiesJoinedAbilitiesOfCard(string cardName)
        {
            List<CardAbilityReturnedModel> abilitiesOfCard = 
                GetCardAbilitiesJoinedAbilitiesQuery()
                .Where(ca => ca.card_name == cardName)
                .ToList();

            return abilitiesOfCard;
        }

        public CardAbility GetOneCardAbilityByCompKey(string abilityName, string cardName)
        {
            CardAbility cardAbility = 
                GetCardAbilitiesQuery()
                .FirstOrDefault(ca => ca.ability_name == abilityName &&
                ca.card_name == cardName);
            return cardAbility;
        }

        public async Task Create(CardAbility cardAbility)
        {
            await db.Card_Abilities.AddAsync(cardAbility);

            await db.SaveChangesAsync();
        }

        public async Task Update(CardAbility cardAbility)
        {
            db.Card_Abilities.Update(cardAbility);

            await db.SaveChangesAsync();
        }

        public async Task Delete(CardAbility cardAbility)
        {
            db.Card_Abilities.Remove(cardAbility);

            await db.SaveChangesAsync();
        }
    }
}
