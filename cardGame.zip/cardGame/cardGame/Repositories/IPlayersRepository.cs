﻿using cardGame.Classes;
using cardGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Repositories
{
    public interface IPlayersRepository
    {
        List<PlayerModel> GetAll();
        Player GetPlayer(string name);
        PlayerModel GetPlayerModel(string name);
        Task Create(Player player);
        Task Update(Player player);
        Task Delete(Player player);
    }
}
