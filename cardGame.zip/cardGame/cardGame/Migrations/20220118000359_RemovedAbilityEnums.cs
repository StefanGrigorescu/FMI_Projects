﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace cardGame.Migrations
{
    public partial class RemovedAbilityEnums : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "trigger_condition",
                table: "Abilities");

            migrationBuilder.DropColumn(
                name: "trigger_moment",
                table: "Abilities");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "trigger_condition",
                table: "Abilities",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "trigger_moment",
                table: "Abilities",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
