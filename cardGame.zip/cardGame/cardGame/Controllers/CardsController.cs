﻿using cardGame.Classes;
using cardGame.Managers;
using cardGame.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardsController : ControllerBase
    {
        private readonly ICardsManager manager;

        public CardsController(ICardsManager cardsManager)
        {
            manager = cardsManager;
        }

        [HttpGet("GetAllCards")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetAllCards()
        {
            var cards = manager.GetAllCards();

            if (cards.Count == 0)
                return NotFound("There are no cards stored in the database");

            return Ok(cards);
        }

        [HttpGet("GetCardsByName/{name}")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetCardsByName([FromRoute] string name)
        {
            var cards = manager.GetCardsByName(name);

            if (cards.Count == 0)
                return NotFound("There are no cards whose names contain the given string stored in the database");

            return Ok(cards);
        }

        [HttpPost("PostFiltersToGetCards")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> PostFiltersToGetCards([FromBody] CardFiltersModel filters)
        {
            var cards = manager.PostFiltersToGetCards(filters);

            if (cards.Count == 0)
                return NotFound("There are no cards matching the filters stored in the database");

            return Ok(cards);
        }

        [HttpPost("CreateOne")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Create([FromBody] CardModel source)
        {
            await manager.Create(source);
            return Ok();
        }

        [HttpPost("CreateSet")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> CreateSet([FromBody] List<CardModel> sourceList)
        {
            await manager.CreateSet(sourceList);
            return Ok();
        }

        [HttpPut]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Update([FromBody] CardModel source)
        {
            await manager.Update(source);
            return Ok();
        }

        [HttpDelete("DeleteByCardName")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Delete([FromBody] string cardName)
        {
            await manager.Delete(cardName);
            return Ok();
        }
    }
}
