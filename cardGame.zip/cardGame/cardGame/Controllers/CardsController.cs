﻿using cardGame.Classes;
using cardGame.Managers;
using cardGame.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardsController : ControllerBase
    {
        private readonly ICardsManager manager;

        public CardsController(ICardsManager cardsManager)
        {
            manager = cardsManager;
        }

        [HttpGet("GetAllCards")]
        public async Task<IActionResult> GetAllCards()
        {
            var cards = manager.GetAllCards();

            return Ok(cards);
        }

        [HttpGet("GetCardsByName/{name}")]
        public async Task<IActionResult> GetCardsByName([FromRoute] string name)
        {
            var cards = manager.GetCardsByName(name);

            return Ok(cards);
        }

        [HttpPost("PostFiltersToGetCards")]
        public async Task<IActionResult> PostFiltersToGetCards([FromBody] CardFiltersModel filters)
        {
            var cards = manager.PostFiltersToGetCards(filters);

            return Ok(cards);
        }

        [HttpPost("CreateOne")]
        public async Task<IActionResult> Create([FromBody] CardModel source)
        {
            await manager.Create(source);
            return Ok();
        }

        [HttpPost("CreateSet")]
        public async Task<IActionResult> CreateSet([FromBody] List<CardModel> sourceList)
        {
            await manager.CreateSet(sourceList);
            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] CardModel source)
        {
            await manager.Update(source);
            return Ok();
        }

        [HttpDelete("DeleteByCardName")]
        public async Task<IActionResult> Delete([FromBody] string cardName)
        {
            await manager.Delete(cardName);
            return Ok();
        }

        /*public IActionResult Index()
        {
            return View();
        }*/
    }
}
