﻿using cardGame.Classes;
using cardGame.Managers;
using cardGame.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PlayersController : ControllerBase
    {
        private readonly IPlayersManager manager;

        public PlayersController(IPlayersManager manager)
        {
            this.manager = manager;
        }


        [HttpGet("GetAllPlayers")]
        public async Task<IActionResult> GetAll()
        {
            var players = manager.GetAll();

            return Ok(players);
        }

        [HttpGet("GetPlayerByName/{name}")]
        public async Task<IActionResult> GetPlayerModel([FromRoute] string name)
        {
            PlayerModel player = manager.GetPlayerModel(name);

            return Ok(player);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] PlayerCreationModel playerCreationModel)
        {
            await manager.Create(playerCreationModel);

            return Ok();
        }

        [HttpPut("ChangePassword")]
        public async Task<IActionResult> UpdatePassword([FromBody] PlayerCreationModel player)
        {
            await manager.UpdatePassword(player.player_name, player.password);

            return Ok();
        }

        [HttpPut("UpdateWinRate")]
        public async Task<IActionResult> UpdateWinRate([FromBody] PlayerUpdateWinRateModel player)
        {
            await manager.UpdateWinRate(player.player_name, player.win_rate);

            return Ok();
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromBody] string name)
        {
            await manager.Delete(name);

            return Ok();
        }
    }
}
