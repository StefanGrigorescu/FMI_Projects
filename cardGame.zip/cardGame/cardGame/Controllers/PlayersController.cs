﻿using cardGame.Classes;
using cardGame.Managers;
using cardGame.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PlayersController : ControllerBase
    {
        private readonly IPlayersManager manager;

        public PlayersController(IPlayersManager manager)
        {
            this.manager = manager;
        }


        [HttpGet("GetAllPlayers")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetAll()
        {
            var players = manager.GetAll();

            if (players.Count == 0)
                return NotFound("There are no players stored in the database");

            return Ok(players);
        }

        [HttpGet("GetPlayerByName/{name}")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetPlayerModel([FromRoute] string name)
        {
            PlayerModel player = manager.GetPlayerModel(name);

            if (player == null)
                return NotFound("There is no player with the given name stored in the database");

            return Ok(player);
        }

        [HttpPost]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> Create([FromBody] PlayerCreationModel playerCreationModel)
        {
            await manager.Create(playerCreationModel);

            return Ok();
        }

        [HttpPut("ChangePassword")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> UpdatePassword([FromBody] PlayerCreationModel player)
        {
            await manager.UpdatePassword(player.player_name, player.password);

            return Ok();
        }

        [HttpPut("UpdateWinRate")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> UpdateWinRate([FromBody] PlayerUpdateWinRateModel player)
        {
            await manager.UpdateWinRate(player.player_name, player.win_rate);

            return Ok();
        }

        [HttpDelete]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Delete([FromBody] string name)
        {
            await manager.Delete(name);

            return Ok();
        }
    }
}
