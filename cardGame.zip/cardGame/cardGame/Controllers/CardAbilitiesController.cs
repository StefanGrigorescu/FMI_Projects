﻿using cardGame.Classes;
using cardGame.Managers;
using cardGame.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardAbilitiesController : ControllerBase
    {
        private readonly ICardAbilitiesManager manager;

        public CardAbilitiesController (ICardAbilitiesManager cardAbilitiesManager)
        {
            manager = cardAbilitiesManager;
        }

        [HttpGet("GetCardAbilities")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetCardAbilitiesJoinedAbilities()
        {
            var cardAbilities = manager.GetCardAbilitiesJoinedAbilities();

            if (cardAbilities.Count == 0)
                return NotFound("There are no card abilities stored in the database");

            return Ok(cardAbilities);
        }

        [HttpGet("GetCardAbilitiesOfCard/{cardName}")]
        [Authorize(Policy = "BasicUserPolicy")]
        public async Task<IActionResult> GetCardAbilitiesJoinedAbilitiesOfCard([FromRoute] string cardName)
        {
            var cardAbilities = manager.GetCardAbilitiesJoinedAbilitiesOfCard(cardName);

            if (cardAbilities.Count == 0)
                return NotFound("There are no card abilities of the given card stored in the database");

            return Ok(cardAbilities);
        }

        [HttpPost("CreateOne")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Create([FromBody] CardAbilityModel source)
        { 
            await manager.Create(source);
            return Ok();
        }

        [HttpPost("CreateSet")]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> CreateSet([FromBody] List<CardAbilityModel> sourceList)
        {
            await manager.CreateSet(sourceList);
            return Ok();
        }

        [HttpPut]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Update([FromBody] CardAbilityModel source)
        {
            await manager.Update(source);
            return Ok();
        }

        [HttpDelete]
        [Authorize(Policy = "AdminPolicy")]
        public async Task<IActionResult> Delete([FromBody] CardAbilityRemovalModel source)
        {
            await manager.Delete(source.ability_name, source.card_name);
            return Ok();
        }
    }
}
