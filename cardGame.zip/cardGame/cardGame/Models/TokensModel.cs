﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class TokensModel
    {
        public string accesToken { get; set; }
    }
}
