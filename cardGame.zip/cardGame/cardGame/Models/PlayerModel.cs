﻿using cardGame.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class PlayerModel
    {
        public string player_name { get; set; }

        public DateTime register_date { get; set; }

        public double win_rate { get; set; }

        public void copy(Player source)
        {
            player_name = source.player_name;
            register_date = source.register_date;
            win_rate = source.win_rate;
        }
    }
}
