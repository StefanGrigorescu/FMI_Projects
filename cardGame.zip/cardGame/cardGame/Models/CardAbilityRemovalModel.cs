﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class CardAbilityRemovalModel
    {
        public string ability_name { get; set; }

        public string card_name { get; set; }
    }
}
