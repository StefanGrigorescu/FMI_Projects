﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class PlayerUpdateWinRateModel
    {
        public string player_name { get; set; }

        public double win_rate { get; set; }
    }
}
