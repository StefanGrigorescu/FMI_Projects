﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class PlayerCreationModel
    {
        public string player_name { get; set; }

        public string password { get; set; }
    }
}
