﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class CardFiltersModel
    {
        public List<string> types;
        public List<string> civilisations;
        public List<string> races;
        public uint energyMin;
        public uint energyMax;
        public uint powerMin;
        public uint PowerMax;
        public bool evolution;
        public List<string> sets;
    }
}
