﻿using cardGame.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class CardReturnedModel
    {
        public string card_name { get; set; }
        public string card_type { get; set; }
        public string civilisation { get; set; }
        public string race { get; set; }
        public uint energy_cost { get; set; }
        public uint power { get; set; }
        public bool evolution_creature { get; set; }
        public string set_name { get; set; }

        public List<CardAbilityOfCardModel> abilitiesList = new List<CardAbilityOfCardModel>();

        public void copy(Card source)
        {
            card_name = source.card_name;
            card_type = source.card_type;
            civilisation = source.civilisation;
            race = source.race;
            energy_cost = source.energy_cost;
            power = source.power;
            evolution_creature = source.evolution_creature;
            set_name = source.set_name;
        }
    }
}
