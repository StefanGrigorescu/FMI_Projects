﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Models
{
    public class CardAbilityOfCardModel
    {
        public string ability_name { get; set; }

        public uint quantity { get; set; }

        public string effect_details { get; set; }

        public void copy(CardAbilityReturnedModel source)
        {
            ability_name = source.ability_name;
            quantity = source.quantity;
            effect_details = source.effect_details;
        }
    }
}
