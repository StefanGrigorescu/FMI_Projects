﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Classes
{
    public class StrategicDetails
    {
        [Required, Key]
        public uint id { get; set; }

        [Required]
        public string card_name { get; set; }

        [Required]
        public string deck_name { get; set; }

        public string role { get; set; }

        public string synergy_details { get; set; }

        public virtual DeckCard deckCard { get; set; }
    }
}
