﻿using cardGame.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace cardGame.Classes
{
    public class Card
    {
        [Required, Key]
        public string card_name { get; set; }

        [Required]
        public string card_type { get; set; }

        [Required]
        public string civilisation { get; set; }

        public string race { get; set; }

        [Required, Range(1,15)]
        public uint energy_cost { get; set; }

        [Range (0,20)]
        public uint power { get; set; }

        public bool evolution_creature { get; set; }

        public string set_name { get; set; }

        public virtual ICollection<DeckCard> deckCards { get; set; }

        public virtual ICollection<CardAbility> cardAbilities { get; set; }

        public void copy(CardModel source)
        {
            card_type = source.card_type;
            civilisation = source.civilisation;
            race = source.race;
            energy_cost = source.energy_cost;
            power = source.power;
            evolution_creature = source.evolution_creature;
            set_name = source.set_name;
        }
        public void copy(Card source)
        {
            card_type = source.card_type;
            civilisation = source.civilisation;
            race = source.race;
            energy_cost = source.energy_cost;
            power = source.power;
            evolution_creature = source.evolution_creature;
            set_name = source.set_name;
        }
    }
}
