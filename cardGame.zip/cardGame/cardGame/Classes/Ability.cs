﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Classes
{
    public class Ability
    {
        [Required, Key]
        public string ability_name { get; set; }

        [Required]
        public string effect_details { get; set; }

        public virtual ICollection<CardAbility> cardAbilities { get; set; }
    }
}
