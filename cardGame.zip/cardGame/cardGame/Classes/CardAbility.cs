﻿using cardGame.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Classes
{
    public class CardAbility
    {
        [Required]
        public string ability_name { get; set; }

        [Required]
        public string card_name { get; set; }

        public uint quantity { get; set; }

        public virtual Ability ability { get; set; }

        public virtual Card card { get; set; }

        public void copy(CardAbilityModel source)
        {
            ability_name = source.ability_name;
            card_name = source.card_name;
            quantity = source.quantity;
        }
        public void copy(CardAbilityReturnedModel source)
        {
            ability_name = source.ability_name;
            card_name = source.card_name;
            quantity = source.quantity;
        }
    }
}
