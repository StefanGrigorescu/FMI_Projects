﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Classes
{
    public class DeckCard
    {
        [Required]
        public string card_name { get; set; }

        [Required]
        public string deck_name { get; set; }

        [Range(1, 4)]
        public uint card_count { get; set; }

        public virtual Card card { get; set; }

        public virtual Deck deck { get; set; }

        public virtual StrategicDetails strategicDetails { get; set; }
    }
}
