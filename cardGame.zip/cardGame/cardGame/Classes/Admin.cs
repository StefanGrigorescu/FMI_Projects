﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace cardGame.Classes
{
    public class Admin
    {
        public static string NewID()
        {
            return Guid.NewGuid().ToString();
        }

        [Required, Key]
        public string admin_code = NewID();

        [Required]
        public string player_name { get; set; }

        public bool admin_state { get; set; }

        public virtual Player player { get; set; }
    }
}
