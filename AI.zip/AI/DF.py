from Base import GraphBase as gBase, NodParcurgereBase as npBase


class GraphDF(gBase.Graph):
    def __init__(self, noduri, matrice, start, scopuri):
        super(GraphDF, self).__init__(noduri, matrice, start, scopuri)

    def genereazaSuccesori(self, nodCurent, nrSolutiiCautate=1):
        listaSuccesori = []
        for i in range(self.nrNoduri):
            if self.matrice[nodCurent.id][i] == 1 and not nodCurent.contineInDrum(self.noduri[i]):
                nodNou = npBase.NodParcurgere(i, self.noduri[i], nodCurent)
                listaSuccesori.append(nodNou)
        return listaSuccesori

    def df(self, nodCurent: npBase.NodParcurgere, nrSolutiiCautate):
        if nrSolutiiCautate <= 0:  # testul acesta s-ar valida doar daca in apelul initial avem df(start,if nrSolutiiCautate=0)
            return nrSolutiiCautate
        #print("Stiva actuala: " + "->".join(nodCurent.obtineDrum()))
        if self.testeazaScop(nodCurent):
            print("Solutie: ", end="")
            nodCurent.afisDrum()
            nrSolutiiCautate -= 1
            if nrSolutiiCautate <= 0:
                return nrSolutiiCautate
        lSuccesori = self.genereazaSuccesori(nodCurent, nrSolutiiCautate)
        for sc in lSuccesori:
            if nrSolutiiCautate > 0:
                #print("Se expandeaza " + nodCurent.__repr__())
                nrSolutiiCautate = self.df(sc, nrSolutiiCautate)
            else:
                break
        #print("Se intoarce -> ")
        return nrSolutiiCautate

    def depthFirst(self, nrSolutiiCautate=1):
        # vom simula o stiva prin relatia de parinte a nodului curent
        self.df(npBase.NodParcurgere(self.noduri.index(self.start), self.start, None), nrSolutiiCautate)

    def dfi(self, nodCurent: npBase.NodParcurgere, adancime, nrSolutiiCautate):
        #print("Stiva actuala: " + "->".join(nodCurent.obtineDrum()))
        if adancime == 1 and self.testeazaScop(nodCurent):
            print("Solutie: ", end="")
            nodCurent.afisDrum()
            nrSolutiiCautate -= 1
            if nrSolutiiCautate <= 0:
                return nrSolutiiCautate
        if adancime > 1:
            lSuccesori = self.genereazaSuccesori(nodCurent, nrSolutiiCautate)
            for sc in lSuccesori:
                if nrSolutiiCautate > 0:
                    nrSolutiiCautate = self.dfi(sc, adancime - 1, nrSolutiiCautate)
        return nrSolutiiCautate

    def depthFirstIterativ(self, nrSolutiiCautate=1):
        for i in range(1, self.nrNoduri + 1):
            if nrSolutiiCautate <= 0:
                return
            print("**************\nAdancime maxima: ", i)
            nrSolutiiCautate = self.dfi(npBase.NodParcurgere(self.noduri.index(self.start), self.start, None), i,
                                        nrSolutiiCautate)
