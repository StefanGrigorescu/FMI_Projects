
# ex 1,2,3  din miniteme sunt rezolvate


