import random
import BF
import DF


class GraphBuilder:
    graphTypes = ["GRAPHBF", "GRAPHDF"]

    @classmethod
    def getGraph(cls, nrNoduri, nrMuchii, nrScopuri, type: str = "GraphBF", orientat=False):
        type = type.upper()
        if type not in cls.graphTypes:
            raise TypeError("Specified Graph Type not allowed. Available types are " + ", ".join(cls.graphTypes))

        noduri = []
        for i in range(0, nrNoduri):
            noduri.append(str(i))

        start = str(random.randint(0, nrNoduri))
        scopuri = []
        while nrScopuri:
            scop = str(random.randint(0, nrNoduri))
            if scop not in scopuri:
                scopuri.append(scop)
                nrScopuri -= 1

        mat = [[0]*nrNoduri]*nrNoduri

        if not orientat:
            nrMuchii = min(nrMuchii, (nrNoduri - 1)//2 * nrNoduri)
            for i in range(1, nrNoduri):
                cont = True
                for j in range(0, i):
                    if mat[i][j] == 0 and random.randint(0, 10) >= 5:
                        mat[i][j] = 1
                        mat[j][i] = 1
                        nrMuchii -= 1
                        if nrMuchii <= 0:
                            cont = False
                            break
                if not cont:
                    break
        else:
            nrMuchii = min(nrMuchii, (nrNoduri - 1) * nrNoduri)
            for i in range(1, nrNoduri):
                cont = True
                for j in range(0, nrNoduri):
                    if mat[i][j] == 0 and random.randint(0, 10) >= 5:
                        mat[i][j] = 1
                        nrMuchii -= 1
                        if nrMuchii <= 0:
                            cont = False
                            break
                if not cont:
                    break

        if type == "GRAPHBF":
            return BF.GraphBF(noduri, mat, start, scopuri)
        else:
            if type == "GRAPHDF":
                return DF.GraphDF(noduri, mat, start, scopuri)
            else:
                return None
