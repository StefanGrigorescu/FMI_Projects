import unittest
import cProfile

import BF
import DF
import GraphBuilder as gBuilder


class MyTestCase(unittest.TestCase):
    #      # Date default pt testare:
    # pozitia i din vectorul de noduri da si numarul liniei/coloanei corespunzatoare din matricea de adiacenta
    noduri = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]

    m = [
        [0, 1, 0, 1, 1, 0, 0, 0, 0, 0],
        [1, 0, 1, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 1, 0, 1, 0, 0],
        [1, 0, 0, 0, 0, 0, 1, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 1, 1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 0, 1, 0, 1, 0, 0, 0, 1, 1],
        [0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 1, 0, 0]
    ]

    start = "a"
    scopuri = ["f", "j"]

    def test_BF(self):
        print("test_BF:")
        gr = BF.GraphBF(self.noduri, self.m, self.start, self.scopuri)
        nrSolutiiCautate = 4

        cProfile.runctx('BF.GraphBF.breadthFirst(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_BFQ(self):
        print("test_BFQ:")
        gr = BF.GraphBF(self.noduri, self.m, self.start, self.scopuri)
        nrSolutiiCautate = 4

        cProfile.runctx('BF.GraphBF.breadthFirstQ(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_DF(self):
        print("test_DF:")
        gr = DF.GraphDF(self.noduri, self.m, self.start, self.scopuri)
        nrSolutiiCautate = 4

        cProfile.runctx('DF.GraphDF.depthFirst(gr, nrSolutiiCautate)', globals(), locals())
        # df(a)->df(b)->df(c)
        #############################################
        self.assertEqual(True, True)

    def test_DFI(self):
        print("test_DFI:")
        gr = DF.GraphDF(self.noduri, self.m, self.start, self.scopuri)
        nrSolutiiCautate = 4

        cProfile.runctx('DF.GraphDF.depthFirstIterativ(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_BF1(self):
        print("test_BF1:")
        gr = gBuilder.GraphBuilder.getGraph(200, 300, 4, "GraphBF")
        nrSolutiiCautate = 4

        cProfile.runctx('BF.GraphBF.breadthFirst(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_BFQ1(self):
        print("test_BFQ1:")
        gr = gBuilder.GraphBuilder.getGraph(200, 300, 4, "GraphBF")
        nrSolutiiCautate = 4

        cProfile.runctx('BF.GraphBF.breadthFirstQ(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_DF1(self):
        print("test_DF1:")
        gr = gBuilder.GraphBuilder.getGraph(200, 300, 4, "GraphDF")
        nrSolutiiCautate = 4

        cProfile.runctx('DF.GraphDF.depthFirst(gr, nrSolutiiCautate)', globals(), locals())

        self.assertEqual(True, True)

    def test_DFI1(self):
        print("test_DFI1:")
        gr = gBuilder.GraphBuilder.getGraph(200, 300, 4, "GraphDF")
        nrSolutiiCautate = 4

        cProfile.runctx('DF.GraphDF.depthFirstIterativ(gr, nrSolutiiCautate)', globals(), locals())


if __name__ == '__main__':
    unittest.main()
