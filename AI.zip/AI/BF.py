from queue import SimpleQueue
from Base import GraphBase as gBase, NodParcurgereBase as npBase


class GraphBF(gBase.Graph):
    def __init__(self, noduri, matrice, start, scopuri):
        super(GraphBF, self).__init__(noduri, matrice, start, scopuri)

    def genereazaSuccesori(self, nodCurent, nrSolutiiCautate=1):
        listaSuccesori = []
        for i in range(self.nrNoduri):
            if self.matrice[nodCurent.id][i] == 1 and not nodCurent.contineInDrum(self.noduri[i]):
                nodNou = npBase.NodParcurgere(i, self.noduri[i], nodCurent)
                listaSuccesori.append(nodNou)
                if self.testeazaScop(nodCurent):
                    print("Solutie: ", end="")
                    nodCurent.afisDrum()
                    nrSolutiiCautate -= 1
                    if nrSolutiiCautate == 0:
                        break
        return (listaSuccesori, nrSolutiiCautate)


    def breadthFirst(self, nrSolutiiCautate = 1):
        # in coada vom avea doar noduri de tip NodParcurgere (nodurile din arborele de parcurgere)
        c = [npBase.NodParcurgere(self.noduri.index(self.start), self.start, None)]

        nodCurent = c[0]
        if self.testeazaScop(nodCurent):
            print("Solutie: ", end="")
            nodCurent.afisDrum()
            nrSolutiiCautate -= 1

        if nrSolutiiCautate > 0:
            while len(c) > 0:
                nodCurent = c.pop(0)

                tuplu = self.genereazaSuccesori(nodCurent, nrSolutiiCautate)
                lSuccesori = tuplu[0]
                nrSolutiiCautate = tuplu[1]

                if nrSolutiiCautate <= 0:
                    break
                c.extend(lSuccesori)


    def breadthFirstQ(self, nrSolutiiCautate = 1):
        # in coada vom avea doar noduri de tip NodParcurgere (nodurile din arborele de parcurgere)
        c = SimpleQueue()
        nodCurent = npBase.NodParcurgere(self.noduri.index(self.start), self.start, None)
        c.put(nodCurent)
        if self.testeazaScop(nodCurent):
            print("Solutie: ", end="")
            nodCurent.afisDrum()
            nrSolutiiCautate -= 1

        if nrSolutiiCautate > 0:
            while not c.empty():
                nodCurent = c.get()

                tuplu = self.genereazaSuccesori(nodCurent, nrSolutiiCautate)
                lSuccesori = tuplu[0]
                nrSolutiiCautate = tuplu[1]

                if nrSolutiiCautate <= 0:
                    break
                for succesor in lSuccesori:
                    c.put(succesor)
